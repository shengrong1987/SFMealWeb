///**
// * Created by shengrong on 11/19/15.
// */
//
////var wolfpack = require('wolfpack'),
//var assert = require('assert'),
//bcrypt = require('bcrypt');
//
////var User = wolfpack('../../../api/models/User'),
////    Auth = wolfpack('../../../api/models/Auth'),
////    Host = wolfpack('../../../api/models/Host');
//
//describe('UsersModel', function() {
//
//  this.timeout(5000);
//
//  describe('#auth signup',function(){
//
//    var password = '12345678';
//    var email = 'auth@gmail.com';
//
//    it('should not find auth account', function(done){
//      Auth.find({email:email}).then(function(results){
//        assert.equal(results.length,0);
//        done();
//      }).catch(done);
//    });
//  });
//
//});
