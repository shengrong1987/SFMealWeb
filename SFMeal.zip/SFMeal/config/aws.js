/**
 * Created by shengrong on 12/15/15.
 */
module.exports.aws = {
  id : 'AKIAJKKQXMC7DOFOMUGA',
  key : '9tn9rGlYmgO1XwaXb1PakS39gdr6XfuxU6mvsrKB',
  bucket : 'sfmeal',
  maxSize : '5242880',
  host : 'https://sfmeal.s3.amazonaws.com/'
}